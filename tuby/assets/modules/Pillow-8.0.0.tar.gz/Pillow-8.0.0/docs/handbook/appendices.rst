Appendices
==========

.. note:: Contributors please include appendices as needed or appropriate with your bug fixes, feature additions and tests.

.. toctree::
  :maxdepth: 2

  image-file-formats
  text-anchors
  writing-your-own-file-decoder
